# Identidade da raposa

Abra `index.html` para visualizar e baixar os arquivos. O manual `manual-da-identidade.pdf` reúne o personagem mestre, o sistema de representação, as vistas, a construção, a paleta, as expressões, as poses e as regras de uso.

## O que foi entregue

| Etapa | Entrega |
| --- | --- |
| 3 — Personagem mestre | Corpo inteiro em 3/4, cabeça, cauda, gradiente, cor sólida, silhueta, preto, reversa branca, monocromia com vazados e fundos claro/roxo. |
| 4 — Sistema | Brand symbol, head mark, full character, avatar, app icon, PNGs de 16/24/32/48/64/128/256 px e favicon ICO com 16/32/48 px. |
| 5 — Character sheet | Vistas principal, frontal, lateral e traseira; pranchas de construção, paleta e aplicações no manual. |
| 6 — Expressões | Oito arquivos individuais: neutro, curioso, feliz, pensando, alerta, satisfeito, leve frustração e comemorando. |
| 7 — Poses | Dez arquivos individuais: indicando informação, observando, analisando dados, notificação, sucesso, erro leve, aguardando, celebrando, ajudando e descansando. |

São **52 SVGs e 52 PNGs**, além do favicon, da galeria, do manual e dos documentos de uso e verificação. O total inclui pranchas e diferentes tamanhos do mesmo símbolo; não significa 52 personagens diferentes.

## Referência adotada

A raposa simplificada grande à esquerda da prancha original aprovada foi a base desta entrega. Ela está preservada em `referencias/modelo-aprovado.png`. A opção 02 da fase 2 não foi automaticamente promovida a uma escolha do usuário. A primeira geração detalhada continua rejeitada.

O pedido para concluir todas as fases e o posterior “Vá, prossiga” orientaram a consolidação do modelo já aprovado. Não foram inventadas novas explorações conceituais para substituir essa escolha.

## Arquivo mestre

Use `03-mestre/raposa-mestre.svg` como matriz vetorial de produção. A geometria foi construída a partir do modelo aprovado, com curvas editáveis e transparência limpa. `03-mestre/raposa-mestre.png` é a exportação correspondente.

O SVG mantém a identidade visual; contém pequenas diferenças de curvas e cor em relação ao PNG original. Não é uma cópia pixel a pixel. A revisão técnica registrou sobreposição de aproximadamente 95,5% entre as máscaras de contorno no mesmo sistema de coordenadas; essa medida não é uma porcentagem de “identidade preservada”.

As novas vistas são construções complementares, e não vistas pré-existentes aprovadas pelo usuário. As oito expressões e as dez poses reutilizam literalmente os mesmos caminhos da cabeça e da máscara, com variações controladas de olhar, inclinação e gesto.

## Escolher o arquivo certo

- **SVG:** ampliar, imprimir e editar em programas vetoriais. São curvas nativas, sem PNG embutido.
- **PNG:** inserir diretamente em sites, apresentações e documentos. Os personagens isolados têm canal alfa real.
- **ICO:** usar como favicon; contém três resoluções reais.
- **PDF:** apresentar ou consultar o sistema completo.

Em 16–32 pixels, use o símbolo reduzido. Prefira a cabeça completa a partir de 64 pixels e o corpo inteiro a partir de 120 pixels. Esses mínimos são orientações visuais para o conjunto entregue, não limites universais de impressão.

## Uso em diferentes fundos

Os personagens coloridos funcionam em fundos claros e roxos. A reversa branca é para fundos escuros. A monocromia do corpo tem vazados transparentes. O avatar e o app icon possuem seus próprios fundos, intencionalmente.

Não estique o desenho, altere a relação cabeça/corpo, acrescente boca, cílios, sobrancelhas, pelo, roupa ou detalhes internos nas orelhas. Os objetos das poses de produto são elementos secundários e não pertencem à identidade principal.

## Consistência e origem

`REGRAS-DA-IDENTIDADE.md` registra os elementos constantes. `validacao/RELATORIO.md` registra os sete testes do briefing e seus limites. `validacao/verificacao-tecnica.json` contém os resultados técnicos por arquivo.

O briefing completo foi preservado em `referencias/briefing-original.txt`. A frase antiga para executar somente a fase 1 pertence ao briefing histórico; a autorização atual do usuário foi para concluir as fases restantes.

Esta entrega foi construída como um sistema vetorial local. Não foi instalado nenhum plugin novo. As orientações de design de interface e PDF foram utilizadas na galeria e no manual.

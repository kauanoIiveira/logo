# Regras da identidade

## Elementos de reconhecimento

1. **Cabeça e orelhas:** cabeça larga com duas orelhas altas, pontas suaves e assimetria controlada. As orelhas não têm desenho interno.
2. **Rosto econômico:** dois olhos ovais roxos, brilho branco mínimo, nariz oval discreto. Não há boca, sobrancelhas, cílios, bigodes ou dentes.
3. **Máscara integrada:** uma área dourada contínua conecta focinho e bochechas, com elevação central sob o nariz e poucos recortes suaves nas laterais.
4. **Cauda de assinatura:** massa ampla em curva ascendente, presa à parte inferior do corpo, com ponta dourada e um recorte interno arredondado.
5. **Corpo e manchas:** patas lisas laranja, coxa arredondada e uma única mancha dourada em gota no peito.

Esses são os elementos constantes desta identidade. Sua documentação não comprova exclusividade de mercado.

## Matriz de construção

O sistema usa as coordenadas da prancha aprovada de 1536 × 1024 como espaço de construção. O quadro de exportação do mestre é `60 55 940 930`.

- Olho esquerdo: centro `(627, 347)`, raios `(20, 31)`.
- Olho direito: centro `(774, 325)`, raios `(19, 31)`.
- Nariz: centro `(701, 393)`, raios `(20, 13)`.
- Inclinação dos olhos na pose principal: cerca de -9 graus.
- Cabeça: aproximadamente 462 de largura × 401 de altura nesse espaço.
- Ponta da orelha esquerda próxima a `(561, 114)`; direita próxima a `(788, 83)`.

As medidas servem à matriz, não à anatomia de uma raposa real. Nas demais vistas, manter a relação entre massas e planos; não copiar coordenadas de frente para um perfil sem considerar a perspectiva.

## Cor

| Função | Cor sólida |
| --- | --- |
| Laranja principal | `#FF8B08` |
| Dourado | `#FFC326` |
| Coral de apoio | `#FF5936` |
| Roxo principal | `#2B0B49` |
| Violeta de apoio | `#64238D` |
| Fundo claro | `#FFF8EE` |

Os gradientes estão definidos nos SVGs: cabeça com coral contido nas pontas, corpo laranja, cauda com transição quente e dourado nas áreas claras. A paleta sólida usa cores fixas; portanto, a versão sólida não é uma amostra de cada pixel do gradiente.

## Expressões e gestos

A forma da cabeça e a máscara são compartilhadas pelos oito arquivos de expressões e dez poses. Os olhos podem fechar ou reduzir sua abertura, preservando centros e linguagem. A inclinação da cabeça é uma transformação do mesmo desenho.

As patas levantadas permanecem formas animais simples, sem mãos ou dedos. Ícones de informação, gráfico, notificação e documento são elementos secundários removíveis no SVG.

## Redução e respiro

O símbolo pequeno elimina gradientes e highlights. A leve compensação dos olhos aumenta a legibilidade em 16–32 pixels. O contorno e a máscara derivam da mesma matriz facial.

Manter uma margem externa de pelo menos a largura de um olho da versão usada. Não distorcer a proporção, encostar orelhas/cauda na borda ou usar o corpo inteiro em 16 pixels.

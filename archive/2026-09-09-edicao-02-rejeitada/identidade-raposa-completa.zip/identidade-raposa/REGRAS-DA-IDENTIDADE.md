# Regras da identidade - edição 02

## Reconhecimento

1. Cabeça larga, orelhas altas com pontas suaves, sem desenho interno. Manter a assimetria da vista principal.
2. Olhos ovais pequenos, pretos (#000000), com um brilho branco mínimo. Nariz oval roxo (#2B0B49). Sem boca, sobrancelhas, cílios, bigodes, dentes, roupas ou mãos.
3. Máscara dourada contínua conectando focinho e bochechas, com poucos recortes suaves nas laterais.
4. Cauda ampla, curva, com ponta dourada e raiz integrada à garupa. A posição acompanha a postura; não flutua ao lado do corpo.
5. Patas lisas e coxas arredondadas. Mancha dourada em gota no peito, encurtada ou oculta pela perspectiva quando necessário.

## Matriz principal

Espaço de construção herdado da prancha de 1536 x 1024. Exportação do mestre: 60 55 940 930.

- Olho esquerdo: centro (627,347), raios (20,31).
- Olho direito: centro (774,325), raios (19,31).
- Nariz: centro (701,393), raios (20,13).
- Inclinação dos olhos: -9 graus.
- Os caminhos da cabeça e da máscara são os mesmos da edição 01.
- A raiz da cauda foi alargada na área encoberta pelo corpo para evitar uma ligação frágil.

## Postura e comportamento

A biblioteca usa ações corporais de uma raposa: apoio sobre quatro patas, passos, farejo, alongamento, repouso e salto. Não usar patas como braços que apontam, seguram objetos, apresentam gráficos ou celebram como mãos humanas. Não criar uma nova pose apenas trocando um símbolo ao lado.

O alongamento abaixa o peito e estende as patas dianteiras mantendo a garupa elevada. O farejo aproxima o focinho do chão. Dormir reúne corpo, cabeça e cauda numa massa compacta. As patas mais distantes usam laranja mais escuro para indicar profundidade; nunca transformar patas em mãos.

Cauda e cabeça se conectam ao corpo também na silhueta. A análise de conexão verifica lacunas geométricas, mas não substitui o julgamento visual da anatomia.

## Vistas e expressões

Frontal: olhos e nariz alinhados, duas coxas e patas dianteiras apoiadas. Lateral: focinho projetado e apenas um olho visível. Traseira: nuca e garupa, sem olho, nariz ou mancha do peito.

As oito expressões mantêm o rosto principal. As poses de farejar e olhar para trás reutilizam o perfil. Não esticar horizontalmente a cabeça para simular perspectiva. Inclinar ou espelhar a vista apropriada como um conjunto.

## Cor e redução

| Função | Cor |
| --- | --- |
| Laranja principal | #FF8B08 |
| Dourado | #FFC326 |
| Coral de apoio | #FF5936 |
| Roxo de apoio e nariz | #2B0B49 |
| Olhos | #000000 |
| Fundo claro | #FFF8EE |
| Brilho dos olhos | #FFFFFF |

Os gradientes quentes permanecem nos SVGs. As patas distantes usam #E77C10 como sombra do laranja. Na versão deliberadamente monocromática, todos os elementos usam a tinta escolhida ou vazados; isso não altera a regra de olhos pretos nas versões coloridas.

Em 16-32 pixels, usar o símbolo sem gradientes e sem brilho. Preservar proporção e uma margem mínima equivalente à largura de um olho. A reversa branca é destinada a fundos escuros. A cauda isolada é um elemento de apoio; nas poses completas ela nunca deve ficar desconectada.

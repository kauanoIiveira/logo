# Identidade da raposa - edição 02

Revisão de 09/09/2026. Abra index.html para consultar e baixar os arquivos. O manual PDF acompanha esta edição.

## O que mudou

- Olhos pretos (#000000), com o mesmo formato e brilho branco. O nariz permanece no roxo original.
- Os gestos humanos e os símbolos das antigas poses de produto foram retirados do conjunto ativo.
- Dez posturas: sentada, em pé, caminhando, farejando o chão, espreguiçando-se, agachada, deitada, dormindo enroscada, saltando e olhando para trás.
- Frontal, lateral e traseira refeitas. A traseira representa efetivamente a nuca e a garupa; o perfil é reutilizado ao farejar e olhar para trás.
- Ligação da cauda reforçada sob a coxa do mestre. Nas novas posturas, a raiz da cauda se sobrepõe ao corpo e acompanha sua orientação.
- Sono com corpo arredondado, cabeça baixa, olhos fechados visíveis e cauda envolvendo o conjunto.

## Arquivos

São 52 SVGs e 52 PNGs, incluindo variantes, vistas, expressões, poses, ícones em sete tamanhos e pranchas. Há também favicon ICO com 16/32/48 pixels, galeria, manual e regras de uso. O total não significa 52 personagens diferentes.

03-mestre contém a matriz, cabeça, cauda, variantes e fundos. 04-sistema contém símbolos, avatar, ícone de aplicativo e favicons. 05-construcao contém quatro vistas. 06-expressoes contém oito expressões. 07-poses contém dez posturas naturais.

Use SVG para ampliar e editar. Use PNG para inserção direta; os personagens isolados têm transparência. Em 16-32 pixels, use o símbolo reduzido. A cabeça completa é recomendada a partir de 64 pixels, e o corpo a partir de 120 pixels.

## Preservação

O PNG aprovado permanece inalterado em referencias/modelo-aprovado.png. O contorno da cabeça e a máscara da matriz vetorial permanecem exatamente iguais aos da edição anterior. A mudança de cor dos olhos e os ajustes anatômicos atendem ao pedido de 09/09.

O perfil é uma construção complementar coerente com a matriz; não é uma vista original previamente aprovada. As poses reutilizam o rosto principal ou esse perfil. A vetorização continua contendo pequenas diferenças em relação ao PNG original. Nenhuma medida técnica comprova identidade visual perfeita.

O pedido atual substitui as antigas poses com ações de interface do briefing histórico. A edição anterior está guardada fora do pacote ativo, em archive/2026-09-07-edicao-01 no projeto, para permitir comparação ou reversão. Não use essa cópia como biblioteca vigente.

As imagens de caminhada e salto são estáticas. Não foi produzida uma animação ou articulação para animar nesta revisão. A fonte vetorial editável permanece no diretório source do projeto.

Nenhum plugin novo foi instalado. REGRAS-DA-IDENTIDADE.md e validacao/RELATORIO.md detalham decisões e verificações.
